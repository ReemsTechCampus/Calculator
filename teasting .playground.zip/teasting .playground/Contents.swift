import UIKit

var str = "Hello, playground"


let r = 5
let s = 8

if (r<s) {
    print("r smaler than s")
}
else if (r==s) {
print("r equal s")
} else{
    print("r greater than s")
}
// ^^ example of "if conditin and if else


///
let numA = 5
let numB = 8

let min = numA < numB ? " \(numA) smaller than \(numB)" : " \(numB) greater than \(numA)"
 print(min)

//^ another way of if condition
// ++
let m = 7
let h = 5

let mun = m < h ? "\(m) smaale than \(h)" : "\(h) greater than \(m)"
print(mun)


///////

switch h {
case 2 :
    print("2")
    break
case 5:
    print("5")
    default:
    print("7")
}
//// ++

let j = 10
switch j {
    case 2 :
    print("2")
    break
    case 5:
    print("5")
    break
    default:
    print("case not valid")
}
//^^ switch examples  ** break

let a = techCampus

if a == "tech" {
    print("1")
    else
  print("1")
} 


///

 
