import UIKit
// oop _ object oreinted programing

// perant classe
class person  {
    
    //properities of class person
    var age :Int!
   private var name : String!
    
    init (age : Int , name : String ) {
        self.age = age
        self.name = name
    }
   
    //func play(sport: String) {
    //print("method spprt")
    
    //}
    
    //func play(instrument: String) {
    //print("metod instrument")
    
    //}
    //func displayName() {
    //print("name: \(name)")
    //}
    //}
    
    //let women = person(age: 25 , name: "Razan")
    //women.age
    //women.displayName()
    //women.play(sport: "basket")}

///child class of the oarent calss
    class men : person {
}
class Team {
    let team: [men]! // [] Array
    
    init (team : [men]) {
        self.team = team
    }
   
    func play() {
        for player in team { // for loop
           print(player.age)
        }
    }
    }

// object of class team
let players = Team (team: [men(age: 22, name: "salman"), men(age: 23, name: "Omar") , men (age: 21, name: "Fahad") , men (age: 38 , name: "Abdullah")])
players.play()

// ^^ polymorphism's explaination


