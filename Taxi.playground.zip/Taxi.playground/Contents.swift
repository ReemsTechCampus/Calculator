import UIKit

// check if there is a near driver
// check car model and type
// check time needed to reach me
// check wich comany is nearer "uber or careen"
// check if driver can take us to a specific destination
// check car size
// check which route is faster
// check driver's gender
// check if multi route is avilable
// check driver rating
// check if diver speak Arabic
// check driver nationality


class driver {
    
//properities
    var name :String!
    var age : Int!
    var carType : String!
    var carModel : Int!
    var carSize : String!
    var gender : String!
    var language : String!
    var nationality :String!
    var location : String!
    
    init(name:String, age:Int, carModel:Int, carType:String, carSize:String, gender:String, language:String, nationality:String, location:String) {
        self.name = name
        self.age = age
        self.carModel = carModel
        self.carType = carType
        self.carSize = carSize
        self.gender = gender
        self.language = language
        self.nationality = nationality
        self.location = location
        
    }
}
 //objec
let driverOne = driver(name: "Ahmad", age: 25, carModel: 2016, carType: "mercedess", carSize: "L", gender: "male", language: "arabic", nationality: "saudi", location: "Med")
let driverTwo = driver(name: "Reem", age: 23, carModel: 2018, carType: "BMW", carSize: "M", gender: "femel", language: "multi languages", nationality: "saudi", location: "Ryiadh")


let myCurrentLocation = "Med"
let myPrefferCar = "BMW"


//nested if//
////// vvvv check current location and has my preferred car type ////////

if myCurrentLocation == driverOne.location {
    if myPrefferCar == driverOne.carType{
    print("\(driverOne.name!) is avilable and has my preffered car type")
    }
    else {
 print("\(driverOne.name!) is avilable but with no my prefferd car ")
}
}  else if myCurrentLocation == driverTwo.location {
      if myPrefferCar == driverTwo.location {
    print("\(driverTwo.name!) is avilale has my preffered car type ")
      } else  {
            print("\(driverTwo.name!)is avilable but with no my prefferd car")
}
}  else {
        print("sorry no driver avilable in your current location")
}

//////// multiple coditions with 2 true events (And) ////////
if myCurrentLocation == driverOne.location && myPrefferCar == driverOne.carType {
    print("\(driverOne.name!) is available and with my preffered car type ")
    
} else if myCurrentLocation == driverTwo.location && myPrefferCar == driverTwo.carType {
        print("\(driverTwo.name!) is vilable and has ny preffered car type")
    
}    else {
            print("sorry no driver avilable in your cuurent location or has my preffered car type ")
    }
/////// ^^ check if driver available and has my preferred car type ///////


///////multiple coditions with One true events (or) ///////
if myCurrentLocation == driverOne.location || myPrefferCar == driverOne.carType {
    print("\(driverOne.name!) is available or with my preffered car type ")
    
} else if myCurrentLocation == driverTwo.location || myPrefferCar == driverTwo.carType {
    print("\(driverTwo.name!) is vilable or has ny preffered car type")
    
}    else {
    print("sorry no driver avilable in your cuurent location or has my preffered car type ")
}
/////// ^^ check if driver available or has my preferred car type ///////

/////////////

////// vvv check driver nationality vvv ////////
switch driverOne.nationality {
case "saudi":
    print("driver's nationality : saudi ")
    break
case "American " :
print("driver's nationality : American ")
default:
    print("driver's nationality : \(driverOne.name!)")
}















