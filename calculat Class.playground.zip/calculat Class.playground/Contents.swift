import UIKit

class calculator {
    var a :Int!
    var b :Int!
    private var result : Int?
    
    init(numA: Int, numB:Int) {
        self.a = numA
        self.b = numB
    }
    func add() {
        result = a + b
    }
    func sub() {
        result = a - b
    }
    
    func divid() {
        result = a / b
    }
    func multi () {
        result = a * b
    }
    func displayResult() {
        print(result!)
    }
    
}
let cal = calculator(numA: 10, numB: 5)
    
cal.add()
cal.displayResult()
cal.divid()
cal.displayResult()
cal.sub()
cal.displayResult()
cal.multi()
cal.displayResult()




